#!/usr/bin/env bash
echo 'Running tests...'
exit 0
