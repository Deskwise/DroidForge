#!/usr/bin/env bash
echo 'Building...'
mkdir -p dist
echo 'ok' > dist/index.html
