# Feature Spec

- Build and test the project.
