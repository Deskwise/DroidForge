import fs from 'node:fs/promises';
import path from 'node:path';
import { mkdirp } from 'mkdirp';
import mustache from 'mustache';

type Signals = { frameworks: string[]; prdPaths: string[]; testConfigs: string[] };

export async function synthesizeDroids(opts: {
  signals?: Signals;
  scripts?: { files: string[] };
  addSingleScript?: string;
  mode?: 'reanalyze' | 'fresh';
}) {
  const cwd = process.cwd();
  const droidDir = path.join(cwd, '.factory', 'droids');
  await mkdirp(droidDir);

  if (opts.addSingleScript) {
    await writeScriptDroid(opts.addSingleScript, droidDir);
    return;
  }

  // Generic core droids (minimal; you can prune later)
  await writeGenericDroid('planner', droidDir);
  await writeGenericDroid('dev', droidDir);
  await writeGenericDroid('reviewer', droidDir);
  await writeGenericDroid('qa', droidDir);
  await writeGenericDroid('auditor', droidDir);

  // Wrap discovered scripts
  for (const f of opts.scripts?.files || []) {
    await writeScriptDroid(f, droidDir);
  }
}

async function writeGenericDroid(name: string, dir: string) {
  const tplPath = new URL('../../templates/droid.generic.md.hbs', import.meta.url);
  const tpl = await (await fs.readFile(tplPath, 'utf8'));
  const body = mustache.render(tpl, { name });
  await fs.writeFile(path.join(dir, `${name}.md`), body, 'utf8');
}

async function writeScriptDroid(filePath: string, dir: string) {
  const tplPath = new URL('../../templates/droid.script.md.hbs', import.meta.url);
  const tpl = await (await fs.readFile(tplPath, 'utf8'));
  const safe = filePath.replace(/[\\/]/g, '-').replace(/\.+/g, '').toLowerCase();
  const name = `script-${safe}`;
  const body = mustache.render(tpl, { name, scriptPath: filePath });
  await fs.writeFile(path.join(dir, `${name}.md`), body, 'utf8');
}
