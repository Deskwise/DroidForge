import fs from 'node:fs/promises';
import path from 'node:path';
import { mkdirp } from 'mkdirp';

export async function writeDroidGuide({ bootstrap = false }: { bootstrap?: boolean }) {
  const cwd = process.cwd();
  const dir = path.join(cwd, 'docs');
  await mkdirp(dir);
  const dest = path.join(dir, 'droid-guide.md');
  const body = `# Droid Guide\n\n- Use Factory CLI interactively.\n- Droids live in .factory/droids/*.md.\n- Orchestrator composes and updates droids based on PRD/README and scripts.`;
  await fs.writeFile(dest, body + '\n', 'utf8');
}
