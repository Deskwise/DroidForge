import fs from 'node:fs/promises';
import path from 'node:path';
import { mkdirp } from 'mkdirp';

export async function writeAgentsMd({ bootstrap = false }: { bootstrap?: boolean }) {
  const cwd = process.cwd();
  const dest = path.join(cwd, 'AGENTS.md');
  const header = `# Agents & Droids\n\nThis repo uses Factory droids (interactive only).`;
  let body = header;
  if (bootstrap) {
    body += `\n\n- Global orchestrator installed at ~/.factory/droids/orchestrator.md`;
  }
  await mkdirp(cwd);
  await fs.writeFile(dest, body + '\n', 'utf8');
}
