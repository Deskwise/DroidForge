import { Command } from 'commander';
import { installGlobalOrchestrator } from './orchestrator/installGlobalOrchestrator.js';
import { scanRepo } from './detectors/repoSignals.js';
import { scanScripts } from './detectors/scripts.js';
import { synthesizeDroids } from './orchestrator/synthesizeDroids.js';
import { writeAgentsMd } from './writers/writeAgentsMd.js';
import { writeDroidGuide } from './writers/writeDroidGuide.js';

export function runCli() {
  const program = new Command();
  program
    .name('droidforge')
    .description('Generate Factory droids from PRD/README and scripts (interactive only)')
    .version('0.1.0');

  program.command('init')
    .description('Install global orchestrator and bootstrap project docs')
    .action(async () => {
      await installGlobalOrchestrator();
      await writeAgentsMd({ bootstrap: true });
      await writeDroidGuide({ bootstrap: true });
      console.log('✅ Initialized: global orchestrator + project docs');
    });

  program.command('scan')
    .description('Analyze PRD/README and discover scripts')
    .action(async () => {
      const signals = await scanRepo(process.cwd());
      const scripts = await scanScripts(process.cwd());
      console.log(JSON.stringify({ signals, scripts }, null, 2));
    });

  program.command('synthesize')
    .description('Create/refresh .factory/droids/* based on repo signals + scripts')
    .action(async () => {
      const signals = await scanRepo(process.cwd());
      const scripts = await scanScripts(process.cwd());
      await synthesizeDroids({ signals, scripts });
      await writeAgentsMd({});
      await writeDroidGuide({});
      console.log('✅ Droids synthesized and docs updated');
    });

  program.command('add-script')
    .argument('<path>', 'Path to script like scripts/build.sh')
    .description('Wrap a single script into a droid')
    .action(async (path) => {
      await synthesizeDroids({ addSingleScript: path });
      await writeAgentsMd({});
      await writeDroidGuide({});
      console.log(`✅ Script wrapped as droid: ${path}`);
    });

  program.command('reanalyze')
    .description('Rescan repo months later and propose new/retired/narrowed droids')
    .action(async () => {
      const signals = await scanRepo(process.cwd());
      const scripts = await scanScripts(process.cwd());
      await synthesizeDroids({ signals, scripts, mode: 'reanalyze' });
      await writeAgentsMd({});
      await writeDroidGuide({});
      console.log('✅ Reanalysis complete. Review proposals in AGENTS.md and docs/droid-guide.md');
    });

  program.parse(process.argv);
}
