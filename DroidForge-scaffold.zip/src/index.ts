import { runCli } from './cli.js';
runCli();
