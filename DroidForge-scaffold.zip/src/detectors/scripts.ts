import { globby } from 'globby';

export async function scanScripts(root: string) {
  const files = await globby([
    'scripts/**/*.{sh,py,ps1}',
    'Makefile',
    'package.json'
  ], { cwd: root, gitignore: true });
  return { files };
}
