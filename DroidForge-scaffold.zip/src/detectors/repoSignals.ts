import { globby } from 'globby';
import fs from 'node:fs/promises';
import path from 'node:path';

export async function scanRepo(root: string) {
  const exists = async (p: string) => !!(await fs.stat(p).catch(() => null));

  const prdPaths = await globby([
    'docs/**/prd/**/*.md',
    'docs/prd/**/*.md',
    'prd/**/*.md',
    'README.md'
  ], { cwd: root, gitignore: true });

  const pkgJsonPath = path.join(root, 'package.json');
  const hasNode = await exists(pkgJsonPath);

  const frameworks: string[] = [];
  if (hasNode) {
    const pkg = JSON.parse(await fs.readFile(pkgJsonPath, 'utf8'));
    const deps = { ...pkg.dependencies, ...pkg.devDependencies } || {};
    for (const k of Object.keys(deps)) {
      if (/react|next|vite|vue|svelte|angular|nuxt/i.test(k)) frameworks.push('frontend');
      if (/express|koa|fastify|hono|nestjs/i.test(k)) frameworks.push('backend');
      if (/jest|vitest|mocha|ava|playwright|cypress/i.test(k)) frameworks.push('testing');
      if (/framer-motion/i.test(k)) frameworks.push('motion');
    }
  }

  const testConfigs = await globby([
    '**/jest*.{js,ts,cjs,mjs}',
    '**/vitest*.{js,ts,cjs,mjs}',
    '**/playwright*.{js,ts,ts}',
    'cypress.config.*',
    '**/pytest.ini',
  ], { cwd: root, gitignore: true });

  return {
    prdPaths,
    frameworks: Array.from(new Set(frameworks)),
    testConfigs,
  };
}
