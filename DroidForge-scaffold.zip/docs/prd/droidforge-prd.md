# DroidForge – PRD (Draft)

## Vision
Turn existing project intent (PRD/README) and scripts into production‑grade Factory droids, dynamically.

## Goals
- Scan PRD/README + scripts
- Generate project droids with Proof
- Install global orchestrator
- Reanalyze later and adapt

## Non‑Goals
- Task management, CI/headless, planning systems

## Success Metrics
- Setup time < 2 min; droid correctness; user adoption
